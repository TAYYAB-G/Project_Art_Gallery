require_relative '../config/environment.rb'




binding.pry

puts "Bob Ross rules."
